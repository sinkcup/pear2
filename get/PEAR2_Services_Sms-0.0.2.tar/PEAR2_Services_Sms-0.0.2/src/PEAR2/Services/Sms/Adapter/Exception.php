<?php
namespace PEAR2\Services\Sms\Adapter;
/**
 * Exception classes
 */

/**
 * Base class for exceptions in PEAR
 */
class Exception extends \PEAR2\Exception
{
}
?>
