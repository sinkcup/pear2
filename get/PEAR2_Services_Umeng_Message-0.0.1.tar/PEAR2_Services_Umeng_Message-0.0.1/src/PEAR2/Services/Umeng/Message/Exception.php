<?php
namespace PEAR2\Services\Umeng\Message;
class Exception extends \PEAR2\Exception {}
?>
